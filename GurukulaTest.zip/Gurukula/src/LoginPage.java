import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class LoginPage {
	
	WebDriver driver;
	
	@Test(dataProvider="LoginData")
	public void LogintoGurukula(String username,String password) throws InterruptedException 
	{
	driver=new FirefoxDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
	//driver.get("http://127.0.0.1:8080/#/");
	//driver.f;
	driver.get("http://127.0.0.1:8080/#/login");
	
	driver.findElement(By.id("username")).sendKeys("");

	driver.findElement(By.id("password")).sendKeys("");
	
	driver.findElement(By.xpath("html/body/div[3]/div[1]/div/div/div/form/button")).click();
	
	Thread.sleep(5000);
	
	System.out.println(driver.getTitle());
	
	Assert.assertTrue(driver.getTitle().contains("You are logged in as user "),"Authentication failed! Please check your credentials and try again");	
	
	System.out.println("user is able to login successfully");
	
	}
	@AfterMethod 
	public void teardown()
	{
		driver.quit();
	}
	@DataProvider(name="LoginData")
	public Object[][] PassData() throws InterruptedException
	{
		Object[][] data=new Object[3][2];
		
		data[0][0]="admin";
		
		data[0][1]="admin";
		
		Thread.sleep(5000);
		
		data[1][0]="1admin";
		
		data[1][1]="admin";
		
		data[2][0]="admin";
		
		data[2][1]="admin1";
		
		return data;
		
		
	}

}
