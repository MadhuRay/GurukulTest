import java.util.concurrent.TimeUnit;
import org.testng.annotations.*;
import static org.testng.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;


public class ForgotPwadAndRegisterNewAccount {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @BeforeClass(alwaysRun = true)
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://127.0.0.1:8080/#";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testForgotPwadAndRegisterNewAccount() throws Exception {
    driver.get(baseUrl + "/#/");
    driver.findElement(By.linkText("login")).click();
    driver.findElement(By.linkText("Did you forget your password?")).click();
    driver.findElement(By.xpath("//input[@name='email' and  @placeholder='Your e-mail']")).clear();
    driver.findElement(By.xpath("//input[@name='email' and  @placeholder='Your e-mail']")).sendKeys("madhuray10@gmail.com");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.findElement(By.cssSelector("span.ng-scope")).click();
    driver.findElement(By.linkText("Register a new account")).click();
    driver.findElement(By.xpath("//input[@name='login' and @placeholder='Your login']")).clear();
    driver.findElement(By.xpath("//input[@name='login' and @placeholder='Your login']")).sendKeys("madhu");
    driver.findElement(By.xpath("//input[@name='email' and @placeholder='Your e-mail']")).clear();
    driver.findElement(By.xpath("//input[@name='email' and @placeholder='Your e-mail']")).sendKeys("madhuray1@gmail.com");
    driver.findElement(By.xpath("//input[@name='password' and @placeholder='New password']")).clear();
    driver.findElement(By.xpath("//input[@name='password' and @placeholder='New password']")).sendKeys("madhu");
    driver.findElement(By.xpath("//input[@name='confirmPassword' and @placeholder='Confirm the new password']")).clear();
    driver.findElement(By.xpath("//input[@name='confirmPassword' and @placeholder='Confirm the new password']")).sendKeys("madhu");
    driver.findElement(By.xpath("//button[text()='Register']")).click();
    driver.findElement(By.linkText("login")).click();
    driver.findElement(By.xpath("//*[@id='username' and  @placeholder='Your login']")).clear();
    driver.findElement(By.xpath("//*[@id='username' and  @placeholder='Your login']")).sendKeys("admin");
    driver.findElement(By.xpath("//*[@id='password' and @placeholder='Your password']")).clear();
    driver.findElement(By.xpath("//*[@id='password' and @placeholder='Your password']")).sendKeys("admin");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    assertEquals(driver.findElement(By.cssSelector("div.row")).getText(), "Welcome to Gurukula! You are logged in as user \"admin\".");
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
