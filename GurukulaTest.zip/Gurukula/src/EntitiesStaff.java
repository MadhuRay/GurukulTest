
//import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.*;
import static org.testng.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class EntitiesStaff {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @BeforeClass(alwaysRun = true)
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://127.0.0.1:8080/#";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testEntitiesStaff() throws Exception {
    driver.get(baseUrl + "/#/");
    driver.findElement(By.linkText("login")).click();
    driver.findElement(By.xpath("//input[@id='username' and  @placeholder='Your login']")).clear();
    driver.findElement(By.xpath("//input[@id='username' and  @placeholder='Your login']")).sendKeys("admin");
    driver.findElement(By.xpath("//input[@id='password' and @placeholder='Your password']")).clear();
    driver.findElement(By.xpath("//input[@id='password' and @placeholder='Your password']")).sendKeys("admin");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//span[text()='Entities']")).click();
    driver.findElement(By.xpath("//span[text()='Staff']")).click();
    Thread.sleep(5000);
    driver.findElement(By.linkText(">>")).click();
    Thread.sleep(5000);
    driver.findElement(By.linkText("<")).click();
    Thread.sleep(5000);
    driver.findElement(By.linkText(">>")).click();
    driver.findElement(By.linkText("<<")).click();
    Thread.sleep(5000);
    driver.findElement(By.linkText("1")).click();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.findElement(By.xpath("(//button[@type='submit'])[3]")).click();
    Thread.sleep(5000);
    driver.findElement(By.cssSelector("button.btn.btn-info")).click();
    driver.findElement(By.xpath("(//button[@type='submit'])[4]")).click();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//input[@type='text' and @name='name']")).clear();
    driver.findElement(By.xpath("//input[@type='text' and @name='name']")).sendKeys("Alex B");
    Thread.sleep(5000);
    new Select(driver.findElement(By.xpath("//select[@name='related_branch']"))).selectByVisibleText("ElectronicsB");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//button[@ng-click='clear()' and @class='btn btn-primary']")).click();
    driver.findElement(By.xpath("//input[@type='text' and @ng-model='staff.name' and @name='name']")).clear();
    driver.findElement(By.xpath("//input[@type='text' and @ng-model='staff.name' and @name='name']")).sendKeys("madhuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
    driver.findElement(By.xpath("//input[@type='text' and @ng-model='staff.name' and @name='name']")).clear();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//input[@type='text' and @ng-model='staff.name' and @name='name']")).sendKeys("sam#1");
    driver.findElement(By.xpath("//input[@type='text' and @ng-model='staff.name' and @name='name']")).clear();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//input[@type='text' and @ng-model='staff.name' and @name='name']")).sendKeys("");
    new Select(driver.findElement(By.xpath("//select[@ng-model='staff.related_branchId' and @name='related_branch']"))).selectByVisibleText("Mechnical");
    driver.findElement(By.xpath("//input[@type='text' and @ng-model='staff.name' and @name='name']")).clear();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//input[@type='text' and @ng-model='staff.name' and @name='name']")).sendKeys("SARINA W");
    new Select(driver.findElement(By.xpath("//select[@ng-model='staff.related_branchId' and @name='related_branch']"))).selectByVisibleText("Mechnical");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
