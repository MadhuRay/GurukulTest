import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WelcomePage 
{

	@Test
	public void VerifyApplicationTitle()
	{
	 WebDriver driver=new FirefoxDriver();
	 driver.manage().window().maximize();
	 driver.get("http://127.0.0.1:8080/#/");
	 //Actual Title
	 String my_title=driver.getTitle();
	 
	 System.out.println("Title is "+my_title);
	 
	 //Excepted Title
	 String expected_title="Welcome to Gurukula!";
	 
	 Assert.assertEquals(my_title, expected_title);
	 
	 System.out.print("Test Completed");
	 }
}
