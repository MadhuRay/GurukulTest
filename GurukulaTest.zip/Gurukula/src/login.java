

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

 @Test public class login{
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @BeforeMethod public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://127.0.0.1:8080/#";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  public void testLoginIDE() throws Exception {
    driver.get(baseUrl + "/#/");
    driver.findElement(By.linkText("login")).click();
    driver.findElement(By.xpath("//input[@id='username' and  @placeholder='Your login']")).clear();
    driver.findElement(By.xpath("//input[@id='username' and  @placeholder='Your login']")).sendKeys("admin1");
    driver.findElement(By.xpath("//input[@id='password' and @placeholder='Your password']")).clear();
    driver.findElement(By.xpath("//input[@id='password' and @placeholder='Your password']")).sendKeys("admin");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.findElement(By.xpath("//input[@id='username' and  @placeholder='Your login']")).clear();
    driver.findElement(By.xpath("//input[@id='username' and  @placeholder='Your login']")).sendKeys("admin23");
    driver.findElement(By.xpath("//input[@id='password' and @placeholder='Your password']")).clear();
    driver.findElement(By.xpath("//input[@id='password' and @placeholder='Your password']")).sendKeys("admin2");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.findElement(By.xpath("//input[@id='username' and  @placeholder='Your login']")).clear();
    driver.findElement(By.xpath("//input[@id='username' and  @placeholder='Your login']")).sendKeys("admin");
    driver.findElement(By.xpath("//input[@id='password' and @placeholder='Your password']")).clear();
    driver.findElement(By.xpath("//input[@id='password' and @placeholder='Your password']")).sendKeys("admin");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
  }

  @AfterMethod public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      Assert.fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
